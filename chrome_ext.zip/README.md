# PauseOnEat
Pause YouTube video when you're taking a bite

Download Chrome Extension zip: https://github.com/sunnyguan/PauseOnEat/raw/main/pauseoneat.zip

Currently using face detection with OpenCV for detection play/pause. Previously used a model trained on my own video to predict eat/watch.
