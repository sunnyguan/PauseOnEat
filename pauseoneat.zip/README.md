# PauseOnEat
Pause YouTube video when you're taking a bite

Currently using face detection with OpenCV for detection play/pause. Previously used a model trained on my own video to predict eat/watch.
